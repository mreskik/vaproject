<?php

$config = [
    //Base Configuration
    //"hostname"          => "localhost",
    "home_direktori"    => "vabpkad",
    // Database Configuration
    "database"          => "db_vapembayaran",
    "user"              => "root",
    "pass"              => ""
];
