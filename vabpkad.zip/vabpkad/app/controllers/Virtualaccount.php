<?php class Virtualaccount extends Controller
{
    public function create()
    {
        $data = [
            "menu-title" => "Buat Transaksi",
            "menu" => "Transaksi / Buat"
        ];
        $this->view("template/header", $data);
        $this->view("virtualaccount/create");
        $this->view("template/footer");
    }
    public function edit()
    {
        $data = [
            "menu-title" => "Edit Transaksi",
            "menu" => "Transaksi / Edit"
        ];
        $this->view("template/header", $data);
        $this->view("virtualaccount/edit");
        $this->view("template/footer");
    }
    public function report()
    {
        $data = [
            "menu-title" => "Laporan Transaksi",
            "menu" => "Transaksi / Laporan"
        ];
        $this->view("template/header", $data);
        $this->view("virtualaccount/report");
        $this->view("template/footer");
    }
    public function detail()
    {
        $data = [
            "menu-title" => "Detail",
            "menu" => "Transaksi / Detail"
        ];
        $this->view("template/header", $data);
        $this->view("virtualaccount/detail");
        $this->view("template/footer");
    }
}
