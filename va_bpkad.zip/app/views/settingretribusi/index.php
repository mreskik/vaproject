<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">

        <!-- Dark table start -->
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-body">

                    <div class="mb-2 row">
                        <div class="form-group col-sm-2">

                            <span class="form-control btn btn-success pt-1 pb-1 font-weight-bold" data-toggle="modal" data-target="#modalTambahRetribusi">Tambah Retribusi</span>
                        </div>
                        <div class="modal fade" id="modalTambahRetribusi" data-backdrop="static">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Tambah Retribusi</h5>
                                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="" class="form">
                                            <div class="form-group">
                                                <label class="col-form-label">Dinas</label>
                                                <select class="custom-select">
                                                    <option selected="selected">Silahakan Pilih</option>
                                                    <option value="1">Retribusi Anak Hilang</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-form-label" for="keteranganretribusi1">Keterangan</label>
                                                <input type="text" class="form-control" maxlength="50" name="keterangan_retribusi" id="keteranganretribusi1">
                                                <div style="font-size: 11px;color: gray;">
                                                    karakter maksimal 50 huruf
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-success">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="data-tables">
                        <table id="dataTableCustom" class="text-center table-striped">
                            <thead class="text-capitalize bg-info" style="color: #fff;">
                                <tr>
                                    <th class="pt-1 pb-1" width="4%">No</th>
                                    <th class="pt-1 pb-1" width="13%">Kode Dinas</th>
                                    <th class="pt-1 pb-1">Nama</th>
                                    <th class="pt-1 pb-1">Keterangan</th>
                                    <th class="pt-1 pb-1" width="10%">aksi</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>11</td>
                                    <td>Dinas Perikanan</td>
                                    <td>Retribusi Ikan Tawar</td>
                                    <td>
                                        <span class="btn btn-primary p-0 pl-1 pr-1">ubah</span>
                                        <span class="btn btn-danger p-0 pl-1 pr-1">hapus</span>
                                    <th></th>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Dark table end -->
    </div>
</div>