<?php class Settingretribusi extends Controller
{
    public function index()
    {
        $data = [
            "menu-title" => "Setting Retribusi",
            "menu" => "Setting Retribusi"
        ];
        $this->view("template/header", $data);
        $this->view("settingretribusi/index");
        $this->view("template/footer");
    }
}
