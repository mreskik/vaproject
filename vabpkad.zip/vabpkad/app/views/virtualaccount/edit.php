<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">

        <!-- Dark table start -->
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-body">
                    <!--<h4 class="header-title">Data Table Dark</h4>-->
                    <div class="data-tables datatable-dark">
                        <table id="dataTableCustom" class="text-center table-striped">
                            <thead class="text-capitalize">
                                <tr>
                                    <th class="pt-1 pb-1" width="2%">No</th>
                                    <th class="pt-1 pb-1">No Virtual Account</th>
                                    <th class="pt-1 pb-1">Nama</th>
                                    <th class="pt-1 pb-1">Keterangan</th>
                                    <th class="pt-1 pb-1">Tagihan</th>
                                    <th class="pt-1 pb-1">Pembayaran</th>
                                    <th class="pt-1 pb-1">Tgl Expired</th>
                                    <th class="pt-1 pb-1">Status</th>
                                    <th class="pt-1 pb-1">aksi</th>

                                </tr>
                            </thead>
                            <tbody>
                            <tr>
                                    <td>1</td>
                                    <td>12345220721001</td>
                                    <td>Dinas Pertanian</td>
                                    <td>Retribusi Pemakaian Mesin Pertanian</td>
                                    
                                    <td>Rp 1.200.000</td><td>Rp 0</td>
                                    <td>21/07/2022</td>
                                    <td>Aktif</td>
                                    <th><span class="btn btn-primary p-0 pl-1 pr-1">detail</span>
                                        <span class="btn btn-warning p-0 pl-1 pr-1">ubah</span>
                                        <span class="btn btn-dark p-0 pl-1 pr-1">nonaktif</span>
                                    </th>
                                </tr><tr>
                                    <td>1</td>
                                    <td>12345220721002</td>
                                    <td>Dinas Pertanian</td>
                                    <td>Retribusi Pemakaian Mesin Pertanian</td>
                                    
                                    <td>Rp 0</td><td>Rp 1.200.000</td>
                                    <td>21/07/2022</td>
                                    <td>Tidak Aktif</td>
                                    <th><span class="btn btn-primary p-0 pl-1 pr-1">detail</span>
                                        <span class="btn btn-warning p-0 pl-1 pr-1">ubah</span>
                                        <span class="btn btn-dark p-0 pl-1 pr-1">nonaktif</span>
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Dark table end -->
    </div>
</div>