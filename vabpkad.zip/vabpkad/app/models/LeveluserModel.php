<?php
class LeveluserModel extends Model
{
    public function __construct()
    {
        $this->table = "level_user";
    }
}
