<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- Dark table start -->

        <div class="col-12 mt-3">
            <?php
            if (isset($_SESSION['flash_message'])) {
            ?>
                <div class="alert alert-<?= ($_SESSION['flash_message'] == 'success') ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <strong><?= ($_SESSION['flash_message'] == 'success') ? 'Success !' : 'Failure !'; ?></strong>
                    <?= ($_SESSION['flash_message'] == 'success') ? $_SESSION['flash_message_info'] . ' berhasil ditambahkan' : $_SESSION['flash_message_info'] . ' gagal ditambahkan'; ?>

                </div>
            <?php
                unset($_SESSION['flash_message']);
                unset($_SESSION['flash_message_info']);
            }
            ?>
            <?php
            if (isset($_SESSION['delete_flash_message'])) {
            ?>
                <div class="alert alert-<?= ($_SESSION['delete_flash_message'] == 'success') ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <strong><?= ($_SESSION['delete_flash_message'] == 'success') ? 'Success !' : 'Failure !'; ?></strong>
                    <?= ($_SESSION['delete_flash_message'] == 'success') ? $_SESSION['flash_message_info'] . ' berhasil dihapus' : $_SESSION['flash_message_info'] . ' gagal dihapus'; ?>

                </div>
            <?php
                unset($_SESSION['delete_flash_message']);
                unset($_SESSION['flash_message_info']);
            }
            ?>
            <?php
            if (isset($_SESSION['update_flash_message'])) {
            ?>
                <div class="alert alert-<?= ($_SESSION['update_flash_message'] == 'success') ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <strong><?= ($_SESSION['update_flash_message'] == 'success') ? 'Success !' : 'Failure !'; ?></strong>
                    <?= ($_SESSION['update_flash_message'] == 'success') ? $_SESSION['flash_message_info'] . ' berhasil diupdate' : $_SESSION['flash_message_info'] . ' gagal diupdate'; ?>

                </div>
            <?php
                unset($_SESSION['update_flash_message']);
                unset($_SESSION['flash_message_info']);
            }
            ?>
            <div class="card">
                <div class="card-body">
                    <div class="mb-2"><span class="btn btn-success pt-1 pb-1 font-weight-bold" id="tambahLevel" data-toggle="modal" data-target="#modalTambahLevelUser">Tambah Level</span></div>
                    <div class="modal fade" id="modalTambahLevelUser" data-backdrop="static">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalUserTitle">Tambah Level User</h5>
                                    <button type="button" class="close closeLevel" data-dismiss="modal"><span>&times;</span></button>
                                </div>
                                <form action="tambahLevel" method="POST" id="formtitit" class="form">
                                    <div class="modal-body">

                                        <div class="form-group">
                                            <label class="col-form-label" for="level">Level</label>
                                            <input type="text" class="form-control" required aria-required="true" name="level" id="level">
                                            <!-- <div style="font-size: 11px;color: gray;">
                                                karakter maksimal 50 huruf
                                            </div> -->
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" name="buat_transaksi" value="buat_transaksi" class="custom-control-input titit" id="buat_transaksi">
                                                <label for="buat_transaksi" class="custom-control-label">Buat Transaksi</label>
                                            </div>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" name="edit_transaksi" value="edit_transaksi" class="custom-control-input" id="edit_transaksi">
                                                <label for="edit_transaksi" class="custom-control-label">Edit Transaksi
                                                </label>
                                            </div>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" name="laporan_transaksi" value="laporan_transaksi" class="custom-control-input" id="laporan_transaksi">
                                                <label for="laporan_transaksi" class="custom-control-label">Laporan Transaksi</label>
                                            </div>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" name="level_user" value="level_user" class="custom-control-input" id="level_user">
                                                <label for="level_user" class="custom-control-label">Level User</label>
                                            </div>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" name="manage_user" value="manage_user" class="custom-control-input" id="manage_user">
                                                <label for="manage_user" class="custom-control-label">Manage User</label>
                                            </div>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" name="setting_retribusi" value="setting_retribusi" class="custom-control-input" id="setting_retribusi">
                                                <label for="setting_retribusi" class="custom-control-label">Setting Retribusi</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary closeLevel" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="hapusLevelModal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Konfirmasi</h5>
                                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                </div>
                                <div class="modal-body">
                                    <p>Apakah anda yakin untuk menghapus user
                                    </p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                    <form action="hapusLevel" method="post">
                                        <input type="hidden" id="inputHapusUserLevel" name="level" >
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="data-tables">
                        <table id="dataTableCustom" class="text-center table-striped">
                            <thead class="text-capitalize bg-dark" style="color: #fff;">
                                <tr>
                                    <th class="pt-1 pb-1" width="2%">No</th>
                                    <th class="pt-1 pb-1" width="30%">Level</th>
                                    <th class="pt-1 pb-1">Hak Akses</th>
                                    <th class="pt-1 pb-1" width=" 15%">aksi</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $a = 1;
                                foreach ($data['data_level'] as $row) :

                                ?>
                                    <tr>
                                        <td><?= $a++; ?></td>
                                        <td><?= $row['level']; ?></td>
                                        <td><?php
                                            $hakakses = explode(",", $row['hak_akses']);
                                            foreach ($hakakses as $key) : ?>
                                                <span class="badge badge-warning badge-pill"><?= $key; ?></span>
                                            <?php endforeach;
                                            ?>
                                        </td>
                                        <td>
                                            <span class="btn btn-primary p-0 pl-1 pr-1 ubahLevel" data-toggle="modal" data-target="#modalTambahLevelUser" data-level='<?= $row['level']; ?>' id="ubahLevel">ubah</span>
                                            <span class="btn btn-danger p-0 pl-1 pr-1 tombolHapusLevel" data-toggle="modal" data-level='<?= $row['level']; ?>' data-target="#hapusLevelModal">hapus</span>
                                        <th></th>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Dark table end -->
    </div>
</div>