<script>
    $(function() {
        $('.selectpicker').selectpicker();
    });
</script>
<div class="main-content-inner">
    <div class="row">
        <div class="col-lg-6 col-ml-12">
            <div class="row">
                <!-- Textual inputs start -->
                <div class="col-12 mt-4">
                    <div class="card">
                        <div class="card-body">
                            <form action="" method="post">


                                <div class="form-row">
                                    <div class="col-sm-3"><label for="example-text-input" class="col-form-label">Prefix</label>
                                        <input class="form-control form-control-sm" type="text" disabled aria-disabled="true" value="12345" id="example-text-input">
                                    </div>
                                    <div class="col-sm-2"> <label for="example-text-input" class="col-form-label">Kode Dinas</label>
                                        <input class="form-control form-control-sm" type="text" disabled aria-disabled="true" value="22" id="example-text-input">
                                    </div>
                                    <div class="col"> <label for="example-text-input" class="col-form-label">Nomor Virtual Account</label>
                                        <input class="form-control form-control-sm" type="text" disabled aria-disabled="true" value="220621001" id="example-text-input">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="example-nama-input" class="col-form-label">Nama</label>
                                    <input class="form-control  pt-1 pb-2" type="text" value="Dinas Pertanian" disabled id="example-nama-input">
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">Keterangan</label>
                                    <select class="custom-select">
                                        <option selected="selected">Silahakan Pilih</option>
                                        <option value="1">Retribusi Anak Hilang</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="example-number-input" class="col-form-label">Tagihan</label>
                                    <input class="form-control pt-1 pb-2" type="number" placeholder="0" id="example-number-input">
                                </div>
                                <div class="row">
                                    <div class="col form-group">
                                        <label for="example-date-input" class="col-form-label">Tanggal Expired</label>
                                        <input class="form-control pt-1 pb-2" type="date" value="<?= date('Y-m-d', strtotime("+1 day", strtotime(date("Y-m-d")))); ?>" id="example-date-input">
                                    </div>
                                    <div class="col form-group">
                                        <label class="col-form-label">Flag Proses</label>
                                        <select class="custom-select">
                                            <option value="1" selected="selected">Full</option>
                                            <!--<option value="2">Partial</option>-->
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <button class="btn btn-success font-weight-bold pt-2 pb-2">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Textual inputs end -->

            </div>
        </div>

    </div>
</div>