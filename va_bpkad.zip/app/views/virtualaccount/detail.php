<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">

        <!-- Dark table start -->
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Data Table Dark</h4>
                    <div class="data-tables datatable-dark">
                        <table id="dataTableCustom" class="text-center table-striped">
                            <thead class="text-capitalize">
                                <tr>
                                    <th width="2%">No</th>
                                    <th>No Virtual Account</th>
                                    <th>Nama</th>
                                    <th>Keterangan</th>
                                    <th>Nominal</th>
                                    <th>aksi</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>1325235346436</td>
                                    <td>Dinas Perdagangan & Perindustrian</td>
                                    <td>Retribusi Pasar Bareng</td>
                                    <td>Rp 1.500.000</td>
                                    <th><span class="btn btn-primary p-0 pl-1 pr-1">detail</span>
                                        <span class="btn btn-warning p-0 pl-1 pr-1">ubah</span>
                                        <span class="btn btn-dark p-0 pl-1 pr-1">nonaktif</span>
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Dark table end -->
    </div>
</div>