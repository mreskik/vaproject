<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Untuk Chrome & Opera -->
    <meta name="theme-color" content="#3b82f6" />
    <!-- Untuk Safari iOS -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#3b82f6" />
    <!-- Untuk Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#3b82f6" />
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SISDA | <?= $data['menu-title']; ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL; ?>/assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/themify-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/metisMenu.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/slicknav.min.css">
    <!-- amcharts css -->
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/export.css" type="text/css" media="all" />
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="<?= BASE_URL; ?>/assets/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="<?= BASE_URL; ?>/assets/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="<?= BASE_URL; ?>/assets/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= BASE_URL; ?>/assets/css/responsive.jqueryui.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/typography.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/default-css.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/styles.css">
    <link rel="stylesheet" href="<?= BASE_URL; ?>/assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="<?= BASE_URL; ?>/assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <style>
        .kolor {
            background: #a60707;
        }

        .metismenu li a i {
            color: #c11515;
            -webkit-transition: all 0.3s ease 0s;
            transition: all 0.3s ease 0s;
        }

        .sidebar-kolor {
            background: linear-gradient(#212529, #212529);
        }

        .breadcrumbs li a,
        .breadcrumbs li span {
            display: block;
            font-size: 14px;
            font-weight: 400;
            color: #ab0707;
            letter-spacing: 0;
            margin-right: 16px;
            position: relative;
        }
    </style>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <div class="sidebar-menu sidebar-kolor">
            <div class="sidebar-header sidebar-kolor pl-0 pr-0">
                <div class="logo">
                    <p style="font-weight: bold;font-size: 17pt; color: #fff; font-family: sans-serif;">RETRIBUSI DAERAH</p>

                </div>
            </div>
            <div class="main-menu shadow-lg">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu ikon-color" id="menu">
                            <li class="<?php ($data['menu-title'] == 'Dashboard') ? print "active" : ''; ?>">
                                <a href="<?= BASE_URL; ?>/dashboard/index" aria-expanded="true"><i class="ti-dashboard "></i><span>dashboard</span></a>

                            </li>
                            <li class="<?php ($data['menu-title'] == 'Buat Transaksi' || $data['menu-title'] == 'Edit Transaksi' || $data['menu-title'] == 'Laporan') ? print "active" : ''; ?>">
                                <a href=" javascript:void(0)" aria-expanded="true"><i class="ti-credit-card "></i><span>Transaksi
                                    </span></a>
                                <ul class="collapse">
                                    <li class="<?php ($data['menu-title'] == 'Buat Transaksi') ? print "active" : ''; ?>"><a href="<?= BASE_URL; ?>/virtualaccount/create">Create Transaksi</a></li>
                                    <li class="<?php ($data['menu-title'] == 'Edit Transaksi') ? print "active" : ''; ?>"><a href="<?= BASE_URL; ?>/virtualaccount/edit">Edit Transaksi</a></li>
                                    <li class="<?php ($data['menu-title'] == 'Laporan') ? print "active" : ''; ?>"><a href="<?= BASE_URL; ?>/virtualaccount/report">Laporan Transaksi</a></li>
                                </ul>
                            </li>
                            <li class="<?php ($data['menu-title'] == 'Manage User' || $data['menu-title'] == 'Level User') ? print "active" : ''; ?>">
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-user"></i><span>User
                                    </span></a>
                                <ul class="collapse">
                                    <li class="<?php ($data['menu-title'] == 'Level User') ? print "active" : ''; ?>"><a href="<?= BASE_URL; ?>/users/level">Level User</a></li>
                                    <li class="<?php ($data['menu-title'] == 'Manage User') ? print "active" : ''; ?>"><a href="<?= BASE_URL; ?>/users/manage">Manage User</a></li>
                                </ul>
                            </li>
                            <li class="<?php ($data['menu-title'] == 'Setting Retribusi') ? print "active" : ''; ?>">
                                <a href="<?= BASE_URL; ?>/settingretribusi/index" aria-expanded="true"><i class="ti-settings"></i><span>Setting Retribusi
                                    </span></a>

                            </li>
                            <li>
                                <a href="<?= BASE_URL; ?>" aria-expanded="true"><i class="ti-share-alt"></i><span>Logout
                                    </span></a>

                            </li>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area pb-0 pt-0">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="search-box pull-left">
                            <form action="#">
                                <input type="text" name="search" placeholder="Search..." required>
                                <i class="ti-search"></i>
                            </form>
                        </div>
                    </div>
                    <!-- profile info & task notification -->
                    <div class="col-md-6 col-sm-4 clearfix ">

                        <div class="user-profile pull-right kolor">
                            <img class="avatar user-thumb" src="<?= BASE_URL; ?>/assets/images/author/avatar.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown">Dinas Pertanian<i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu border  pb-1 pt-1">
                                <a class="dropdown-item text-center">Logout</a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- header area end -->
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area mt-2">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left " style="color:black; font-weight: 500;"><?= $data['menu-title']; ?></h4>
                            <ul class="breadcrumbs pull-left">
                                <li><span class=""><?= $data['menu']; ?></span></li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>