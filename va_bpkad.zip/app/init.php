<?php

require "config/Config.php";
define('BASE_URL', $_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['SERVER_NAME'] . "/" . $config['home_direktori']);
define('HOME_DIRECTORY', $config['home_direktori']);
require_once "core/App.php";
require_once "core/Controller.php";
require_once "core/Model.php";


new App;
