<?php

$config = [
    //Base Configuration
    //"hostname"          => "localhost",
    "home_direktori"    => "va_bpkad",
    // Database Configuration
    "database"          => "db_vapembayaran",
    "user"              => "root",
    "pass"              => ""
];
