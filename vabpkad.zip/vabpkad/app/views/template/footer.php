</div>
<!-- main content area end -->
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>Developed by <a target="_blank" href="https://www.linkedin.com/in/mrk404">Reski</a>.</p>
    </div>
</footer>
<!-- footer area end-->
</div>
<!-- page container area end -->
<!-- offset area start -->

<!-- offset area end -->
<!-- jquery latest version -->
<script src="<?= BASE_URL; ?>/assets/js/vendor/jquery-2.2.4.min.js"></script>


<!-- bootstrap 4 js -->
<script src="<?= BASE_URL; ?>/assets/js/popper.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/bootstrap.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/owl.carousel.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/metisMenu.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/jquery.slimscroll.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/jquery.slicknav.min.js"></script>

<!-- Start datatable js -->
<script src="<?= BASE_URL; ?>/assets/js/jquery.dataTables.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/jquery.dataTables.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/dataTables.responsive.min.js"></script>
<script src="<?= BASE_URL; ?>/assets/js/responsive.bootstrap.min.js"></script>



<!-- start chart js -->
<script src="<?= BASE_URL; ?>/assets/js/Chart.min.js"></script>
<!-- start highcharts js -->
<script src="<?= BASE_URL; ?>/assets/js/highcharts.js"></script>
<!-- start zingchart js -->
<script src="<?= BASE_URL; ?>/assets/js/zingchart.min.js"></script>

<!-- all line chart activation -->
<script src="<?= BASE_URL; ?>/assets/js/line-chart.js"></script>
<!-- all pie chart -->
<script src="<?= BASE_URL; ?>/assets/js/pie-chart.js"></script>

<!-- others plugins -->
<script src="<?= BASE_URL; ?>/assets/js/plugins.js"></script>

<script src="<?= BASE_URL; ?>/assets/js/scripts.js"></script>
<script>
    $('#dataTableCustom').dataTable({
        paging: true,
        responsive: true
    });
</script>
</body>

</html>