<?php

class Model
{
    protected $table = "";
    protected function connect()
    {
        require "app/config/Config.php";
        return mysqli_connect("localhost", $config['user'], $config['pass'], $config['database']);
    }

    public function query($kueri)
    {
        return mysqli_query($this->connect(), $kueri);
    }

    public function show($table = [])
    {
        if (!empty($table)) {
            $this->table = $table;
        }

        return $this->query("SELECT * FROM " . $this->table);
    }
}
