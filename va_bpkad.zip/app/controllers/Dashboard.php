<?php
class Dashboard extends Controller
{
    public function index()
    {
        $data = [
            "menu-title" => "Dashboard",
            "menu" => "Dashboard"
        ];
        $this->view("template/header", $data);
        $this->view("dashboard/index");
        $this->view("template/footer");
    }
}
