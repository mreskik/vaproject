<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">

        <!-- Dark table start -->
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-body">

                    <!-- <h4 class="header-title col-sm-2">Manage User</h4> -->
                    <div class="mb-2"><span class="btn btn-success pt-1 pb-1 font-weight-bold">Tambah User</span></div>



                    <div class="data-tables">
                        <table id="dataTableCustom" class="text-center table-striped">
                            <thead class="text-capitalize bg-dark" style="color: #fff;">
                                <tr>
                                    <th width="5%" class="pt-1 pb-1">No</th>
                                    <th class="pt-1 pb-1">Kode Dinas</th>
                                    <th class="pt-1 pb-1">Nama</th>
                                    <th class="pt-1 pb-1">Level</th>
                                    <th class="pt-1 pb-1">Username</th>
                                    <th class="pt-1 pb-1">Password</th>
                                    <th width="15%" class="pt-1 pb-1">aksi</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>01</td>
                                    <td>Dinas Perdagangan & Perindustrian</td>
                                    <td>admin</td>
                                    <td>dinasperdagangan</td>
                                    <td>*******</td>
                                    <th><span class="btn btn-primary p-0 pl-1 pr-1">detail</span>
                                        <span class="btn btn-warning p-0 pl-1 pr-1">ubah</span>
                                        <span class="btn btn-danger p-0 pl-1 pr-1">hapus</span>
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Dark table end -->
    </div>

</div>