<?php


class Users extends Controller
{
    public $leveluser = [], $manageuser = [];
    public function __construct()
    {
        session_start();
        require 'app/models/LeveluserModel.php';
        $this->leveluser = new LeveluserModel;
    }
    public function manage()
    {
        $data = [
            "menu-title" => "Manage User",
            "menu" => "User / Manage",
            "daftar_level_user" => $this->leveluser->show()->fetch_all(MYSQLI_ASSOC)
        ];
        $this->view("template/header", $data);
        $this->view("users/manage", $data);
        $this->view("template/footer");
    }
    public function level()
    {

        $data = [
            "menu-title" => "Level User",
            "menu" => "User / Level",
            "data_level" => $this->leveluser->show()->fetch_all(MYSQLI_ASSOC)
        ];
        $this->view("template/header", $data);
        $this->view("users/level", $data);
        $this->view("template/footer");
    }

    public function tambahLevel()
    {
        print_r($_POST);

        if (isset($_POST)) {
            $level = addslashes($_POST['level']);
            unset($_POST['level']);
            $hak_akses = "";
            foreach ($_POST as $key) {
                $hak_akses = $hak_akses . "," . $key;
            }
            $hak_akses = trim($hak_akses, ",");
            $hak_akses = addslashes($hak_akses);
            $_SESSION['flash_message_info'] = $level;
            if ($this->leveluser->query("INSERT INTO level_user(level, hak_akses) VALUES('$level', '$hak_akses')")) {
                $_SESSION['flash_message'] = "success";
                header("location:" . BASE_URL . "/users/level");
            } else {
                $_SESSION['flash_message'] = "fail";
                header("location:" . BASE_URL . "/users/level");
            };
        }
    }

    public function editLevel()
    {
        print_r($_POST);

        if (isset($_POST)) {
            $level = addslashes($_POST['level']);
            unset($_POST['level']);
            $hak_akses = "";
            foreach ($_POST as $key) {
                $hak_akses = $hak_akses . "," . $key;
            }
            $hak_akses = trim($hak_akses, ",");
            $hak_akses = addslashes($hak_akses);
            $_SESSION['flash_message_info'] = $level;
            if ($this->leveluser->query("UPDATE level_user SET hak_akses='$hak_akses' WHERE level='$level'")) {
                $_SESSION['update_flash_message'] = "success";
                header("location:" . BASE_URL . "/users/level");
            } else {
                $_SESSION['update_flash_message'] = "fail";
                header("location:" . BASE_URL . "/users/level");
            };
        }
    }

    public function getLevel()
    {
        $level = addslashes($_POST['level']);
        print($this->leveluser->query("SELECT hak_akses FROM level_user WHERE level='$level'")->fetch_assoc()['hak_akses']);
    }

    public function hapusLevel()
    {
        print_r($_POST);
        $level = addslashes($_POST['level']);
        print $this->leveluser->query("DELETE FROM level_user WHERE level='$level'");

        if (isset($_POST)) {
            $level = addslashes($_POST['level']);
            $_SESSION['flash_message_info'] = $level;
            if ($this->leveluser->query("DELETE FROM level_user WHERE level='$level'")) {
                $_SESSION['delete_flash_message'] = "success";
                header("location:" . BASE_URL . "/users/level");
            } else {
                $_SESSION['delete_flash_message'] = "fail";
                header("location:" . BASE_URL . "/users/level");
            };
        }
    }


    //action

}
