<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">

        <!-- Dark table start -->
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-body">
                    <div class="mb-2 row">
                        <div class="form-group col-sm-3">
                            <label for="example-date-awal" class="col-form-label">Tanggal Awal</label>
                            <input class="form-control pt-1 pb-1" type="date" value="<?= date('Y-m-d'); ?>" id="example-date-awal">
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="example-date-akhir" class="col-form-label">Tanggal Akhir</label>
                            <input class="form-control pt-1 pb-1" type="date" value="<?= date('Y-m-d'); ?>" id="example-date-akhir">
                        </div>
                        <div class="form-group col-sm-2">
                            <label for="example-date-input" class="col-form-label mb-3"></label>
                            <span class=" form-control btn btn-dark pt-1 pb-1 font-weight-bold">Generate</span>
                        </div>
                        <div class="form-group col-sm-2">
                            <label for="example-date-input" class="col-form-label mb-3"></label>
                            <span class=" form-control btn btn-primary pt-1 pb-1 font-weight-bold">Export Excel</span>
                        </div>
                    </div>
                    <div class="data-tables datatable-dark">
                        <table id="dataTableCustom" class="text-center table-striped">
                            <thead class="text-capitalize">
                                <tr>
                                    <th class="pt-1 pb-1" width="2%">No</th>
                                    <th class="pt-1 pb-1">No Virtual Account</th>
                                    <th class="pt-1 pb-1">Nama</th>
                                    <th class="pt-1 pb-1">Keterangan</th>
                                    <th class="pt-1 pb-1">Nominal</th>
                                    <th class="pt-1 pb-1">Tanggal Trx</th>


                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>12345220721001</td>
                                    <td>Dinas Pertanian</td>
                                    <td>Retribusi Pinjam Alat Pertanian</td>
                                    <td>Rp 1.200.000</td>
                                    <td>22/07/2022</td>


                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Dark table end -->
    </div>
</div>