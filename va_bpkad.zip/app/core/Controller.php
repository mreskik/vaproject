<?php
class Controller
{
    protected function view($url, $data = [])
    {
        require_once "app/views/" . $url . ".php";
    }
}
